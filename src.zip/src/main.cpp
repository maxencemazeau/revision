#include <Arduino.h>
#include "TemperatureStub.h"
#define DHTPIN  15   // Pin utilisée par le senseur DHT11 / DHT22
#define DHTTYPE DHT22  //Le type de senseur utilisé (mais ce serait mieux d'avoir des DHT22 pour plus de précision)
TemperatureStub *temperatureStub = NULL;

//Définition de la LED
#define GPIO_PIN_LED_LOCK_ROUGE         12 //GPIO12

void setup() { 
    Serial.begin(9600);
    delay(100);

//Initiation pour la lecture de la température
    temperatureStub = new TemperatureStub;
    temperatureStub->init(DHTPIN, DHTTYPE); //Pin 15 et Type DHT11

//Initialisation de la LED
    pinMode(GPIO_PIN_LED_LOCK_ROUGE,OUTPUT);  

}

void loop() {
  // put your main code here, to run repeatedly:

  float t = temperatureStub->getTemperature();

  Serial.println(t);

  if(t > 25) {
    digitalWrite(GPIO_PIN_LED_LOCK_ROUGE,HIGH);
  } else {
    digitalWrite(GPIO_PIN_LED_LOCK_ROUGE,LOW);
  }
}